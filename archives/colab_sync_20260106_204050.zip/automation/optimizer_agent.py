#!/usr/bin/env python3
"""
SRCL Optimizer Agent v2.0
------------------------------------------------------------
Runs genetic optimization on the SRCL environmental ripple simulation.
Each generation:
  • Randomly mutates parameters (alpha, beta, gamma, D)
  • Launches SRCL simulations
  • Reads JSONL metrics logs
  • Computes real fitness = coherence / (1 + |entropy|)
  • Evolves toward higher structural coherence / stability
------------------------------------------------------------
"""

import subprocess, json, random, os, numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
from tqdm import trange

# ============================================================
# CONFIG
# ============================================================

OUTPUT_DIR = Path("data/optimizer")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

GENERATIONS = 5
POP_SIZE = 8
STEPS = 1000  # passed to SRCL sim

# Parameter search ranges
RANGES = {
    "alpha": (0.05, 0.1),
    "beta": (0.08, 0.12),
    "gamma": (0.3, 0.9),
    "D": (0.6, 1.0),
}

# ============================================================
# FITNESS EVALUATION
# ============================================================

def evaluate_run(log_path: Path) -> float:
    """Read JSONL metrics log and calculate fitness based on coherence/entropy."""
    try:
        data = []
        with open(log_path, "r") as f:
            for line in f:
                try:
                    data.append(json.loads(line))
                except json.JSONDecodeError:
                    continue

        if not data:
            return -999.0

        coh = [d["coherence_A"] for d in data if "coherence_A" in d]
        ent = [d["entropy_A"] for d in data if "entropy_A" in d]
        if not coh or not ent:
            return -999.0

        avg_coh = np.mean(coh)
        avg_ent = np.mean(ent)

        # Fitness: maximize coherence, penalize high entropy (chaos)
        fitness = float(avg_coh / (1.0 + abs(avg_ent)))
        return fitness

    except Exception as e:
        print(f"⚠️ Error evaluating {log_path}: {e}")
        return -999.0

# ============================================================
# PARAMETER UTILITIES
# ============================================================

def random_params():
    return {k: random.uniform(*v) for k, v in RANGES.items()}

def mutate_params(params, rate=0.1):
    mutated = {}
    for k, v in params.items():
        low, high = RANGES[k]
        jitter = random.uniform(-rate, rate) * (high - low)
        mutated[k] = float(np.clip(v + jitter, low, high))
    return mutated

# ============================================================
# MAIN OPTIMIZER LOOP
# ============================================================

def run_optimizer():
    best_params = None
    best_fitness = -999.0
    history = []

    for gen in range(1, GENERATIONS + 1):
        print(f"\n🌱 Generation {gen}/{GENERATIONS}")

        # Create population
        if gen == 1:
            population = [random_params() for _ in range(POP_SIZE)]
        else:
            # mutate previous bests
            population = [mutate_params(best_params) for _ in range(POP_SIZE)]

        gen_results = []

        for i, params in enumerate(population):
            log_path = OUTPUT_DIR / f"log_{os.getpid()}_{gen:02d}_{i:02d}.jsonl"

            # Run SRCL simulation
            cmd = [
                "python", "srcl_core/srcl_environmental_ripple.py",
                "--alpha", str(params["alpha"]),
                "--beta", str(params["beta"]),
                "--gamma", str(params["gamma"]),
                "--D", str(params["D"]),
                "--log", str(log_path)
            ]

            print(f"🚀 Running sim: {params}")
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            # Evaluate fitness
            fitness = evaluate_run(log_path)
            print(f"  [{i}] Fitness = {fitness:.6f}")

            gen_results.append((params, fitness))

        # Pick best from generation
        best_gen_params, best_gen_fitness = max(gen_results, key=lambda x: x[1])
        if best_gen_fitness > best_fitness:
            best_params, best_fitness = best_gen_params, best_gen_fitness

        print(f"🏆 Best so far: {best_params} → {best_fitness:.6f}")
        history.append(best_fitness)

    # Plot evolution
    plt.figure(figsize=(7, 4))
    plt.plot(history, marker="o")
    plt.title("🧠 Fitness Evolution over Generations")
    plt.xlabel("Generation")
    plt.ylabel("Fitness")
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / "fitness_evolution.png", dpi=200)

    print(f"\n✅ Optimization complete! Results saved → {OUTPUT_DIR}")

# ============================================================
# ENTRYPOINT
# ============================================================

if __name__ == "__main__":
    run_optimizer()

